import boto3
import csv
import os
import json
from urllib.parse import unquote_plus

s3       = boto3.client('s3')
sns      = boto3.client('sns')
dynamodb = boto3.resource('dynamodb')

def lambda_handler(event, context):
    # 1. Decode file key (handles spaces in filenames)
    bucket_name = event['Records'][0]['s3']['bucket']['name']
    file_key    = unquote_plus(event['Records'][0]['s3']['object']['key'])

    # 2. Get Env Vars safely (using .get avoids crashing the whole function)
    table_name = os.environ.get('DYNAMODB_TABLE', 'MISSING_TABLE_NAME')
    topic_arn  = os.environ.get('SNS_TOPIC_ARN', 'MISSING_TOPIC_ARN')

    print(f"Targeting Table: {table_name}")

    try:
        # Download and read file
        response = s3.get_object(Bucket=bucket_name, Key=file_key)
        # utf-8-sig automatically removes the hidden BOM character if it exists
        content  = response['Body'].read().decode('utf-8-sig')
        lines    = content.splitlines()

        reader = csv.DictReader(lines)
        table  = dynamodb.Table(table_name)

        count = 0
        for row in reader:
            # Clean spaces from column names automatically
            clean_row = {k.strip(): v.strip() for k, v in row.items()}
            
            # Use the clean key
            order_id = clean_row.get('order_id', f"unknown-{count}")

            table.put_item(Item={
                'order_id': order_id,
                'data':     json.dumps(clean_row),
                'file_key': file_key,
                'timestamp': context.aws_request_id # Good for tracking
            })
            count += 1

        # Success Notification
        if topic_arn != 'MISSING_TOPIC_ARN':
            sns.publish(
                TopicArn = topic_arn,
                Subject  = "Pipeline Success",
                Message  = f"Processed {count} rows from {file_key}"
            )

        return {'statusCode': 200, 'body': 'Success'}

    except Exception as e:
        error_message = f"Error processing {file_key}: {str(e)}"
        print(error_message)

        # Failure Notification (Safety Check: only send if we have an ARN)
        if topic_arn != 'MISSING_TOPIC_ARN':
            sns.publish(TopicArn=topic_arn, Subject="Pipeline Failed", Message=error_message)
        
        raise e